# Air Quality Dashboard
## Setup Environment-Anaconda
conda create --name main-ds python=3.9<br>
conda activate main-ds.<br>

## Run Streamlit App
streamlit run dashboard.py<br>
